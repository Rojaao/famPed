# Robô FamPed - Estratégia Inteligente para Deriv

✅ Estratégia FAMPED: Analisa os 33 últimos dígitos e entra em Digit Over 3 ou 4 com base em padrões fortes.  
✅ Compatível com tokens reais ou demo da Deriv  
✅ Interface via Streamlit, com logs ao vivo e gráfico de desempenho  
✅ Totalmente pronto para publicação no Streamlit Cloud